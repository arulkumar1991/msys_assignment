using System;
using System.Collections.Generic;
using Moq;
using Msys;
using Msys.Controllers;
using Xunit;

namespace MsysTest
{
    public class ServiceTest
    {
        public Mock<IGenericRepository<ServiceRequestEntity>> mock = new Mock<IGenericRepository<ServiceRequestEntity>>();
        ServiceRequestEntity seviceDetail = new ServiceRequestEntity(){
                 
                    Id= new Guid("727b376b-79ae-498e-9cff-a9f51b848ea4"),
                    buildingCode= "COH",
                    description = "Please turn up the AC in suite 1200D. It is too hot here.",
                    createdBy   = "Nik Patel",
                    createdDate = new DateTime(2019,8,7),
                    lastModifiedBy = "Jane Doe",
                    lastModifiedDate = new DateTime(2019,8,7)
    
         };
        [Fact]
        public async void Add()
        {
            bool values = false;
            mock.Setup(p => p.Add(seviceDetail)).Returns(values);
            ServiceRequestController service = new ServiceRequestController(mock.Object);
            var result = await service.Get();
            
            Assert.Equal("OkObjectResult", result.Result.GetType().Name.ToString());
        }

        [Fact]
        public async void GetServiceRequestDetails()
        {


            mock.Setup(p => p.GetById(seviceDetail.Id)).Returns(seviceDetail);
            ServiceRequestController service = new ServiceRequestController(mock.Object);
            var result = await service.Get();
            Assert.Equal("727b376b-79ae-498e-9cff-a9f51b848ea4", seviceDetail.Id.ToString());
        }
       
    }
}
