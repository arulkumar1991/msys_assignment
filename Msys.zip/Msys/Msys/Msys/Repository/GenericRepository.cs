﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace Msys
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        public ICacheService _cacheService;
        private const string _cacheKeyName = "ServiceRequests";
        public GenericRepository(ICacheService cacheService)
        {
            _cacheService = cacheService;

        }

        public bool Add(T entity)
        {
            var allServiceRequests = this.GetAll().ToList();
            T existingObj = allServiceRequests.SingleOrDefault(obj => getProperty(obj, "Id").GetValue(obj).Equals(Convert.ChangeType(getProperty(entity, "Id").GetValue(entity), getProperty(obj, "Id").PropertyType)));
            if(existingObj == null)
            {
                allServiceRequests.Add(entity);
                _cacheService.Set(_cacheKeyName, allServiceRequests);
                return true;
            }
            return false;
        }

        public bool Delete(Guid? id, T entity)
        {
            List<T> allServiceRequests = this.GetAll().ToList();
            bool isObjectRemoved = false;
            if (id != null)
                isObjectRemoved = allServiceRequests.Remove((T)allServiceRequests.SingleOrDefault(obj => getProperty(obj, "Id").GetValue(obj).Equals(Convert.ChangeType(id, getProperty(obj, "Id").PropertyType))));
            else
                isObjectRemoved = allServiceRequests.Remove((T)allServiceRequests.SingleOrDefault(obj => getProperty(obj, "Id").GetValue(obj).Equals(Convert.ChangeType(getProperty(entity, "Id").GetValue(entity), getProperty(obj, "Id").PropertyType))));
            _cacheService.Set(_cacheKeyName, allServiceRequests);
            return isObjectRemoved;
        }

        public IEnumerable<T> GetAll()
        {
            List<T> allServiceRequests;
            _cacheService.TryGet(_cacheKeyName, out allServiceRequests);
            return allServiceRequests;
        }

        public T GetById(Guid id)
        {
            T retObj = this.GetAll().FirstOrDefault(obj=> getProperty(obj, "Id").GetValue(obj).Equals(Convert.ChangeType(id, getProperty(obj, "Id").PropertyType)));
            return retObj;
        }

        private PropertyInfo getProperty(T obj, string propertyName)
        {
            return obj.GetType().GetProperty(propertyName);
        }

        public bool Update(Guid id, T entity)
        {
            bool isObjectRemoved = this.Delete(id, entity);
            if (isObjectRemoved)
            {
                this.Add(entity);
                return true;
            }

            return false;
           
        }

        public void SetDefaultData()
        {
            var allServiceRequests = this.GetAll();
            if (allServiceRequests == null)
            {
                string initialDataFromJsonFile = File.ReadAllText("_initialData.json");
                var initialData = JsonConvert.DeserializeObject<List<ServiceRequestEntity>>(initialDataFromJsonFile);
                initialData.ForEach(obj => { 
                    if (obj.Id == Guid.Empty) obj.Id = Guid.NewGuid(); 
                });
                _cacheService.Set(_cacheKeyName, initialData);
            }
        }
    }
}
