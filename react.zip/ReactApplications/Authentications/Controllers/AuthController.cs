﻿namespace Authentications.Controllers
{
    using System;
    using System.IdentityModel.Tokens.Jwt;
    using System.Security.Claims;
    using System.Text;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using Microsoft.IdentityModel.Tokens;
    using Microsoft.AspNetCore.Authentication.JwtBearer;
    using Microsoft.IdentityModel.Tokens;
    using System.IdentityModel.Tokens.Jwt;
    using System.Security.Claims;

    [Route("api/[controller]")]
    public class AuthController : Controller
    {
        private readonly string _key;

        public AuthController(string key)
        {
            _key = key;
        }

        [HttpGet]
        public string Get(string name, string pwd)
        {
            if (name == "catcher" && pwd == "123")
            {
                //if (!users.Any(u => u.Key == username && u.Value == password))
                //{
                //    return null;
                //}
                // Create JWT Token, if it matches
                var tokenHandler = new JwtSecurityTokenHandler();
                var tokenKey = Encoding.ASCII.GetBytes(_key);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                    {
                    new Claim(ClaimTypes.Name, pwd)
                    }),
                    Expires = DateTime.UtcNow.AddHours(1),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(tokenKey),
                        SecurityAlgorithms.HmacSha256Signature)
                };

                // it will return token
                var token = tokenHandler.CreateToken(tokenDescriptor);
                // JWT will be returned from here
                return tokenHandler.WriteToken(token);
            }
            else
            {
                return null;
            }
        }
    }

   
}
